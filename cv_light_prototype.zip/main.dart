import 'package:flutter/material.dart';

void main() {
  runApp(CVLightApp());
}

class CVLightApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'C.V Light Prototype',
      theme: ThemeData(
        primarySwatch: Colors.blue,
        visualDensity: VisualDensity.adaptivePlatformDensity,
      ),
      home: MainPage(),
    );
  }
}

class MainPage extends StatefulWidget {
  @override
  _MainPageState createState() => _MainPageState();
}

class _MainPageState extends State<MainPage> {
  int _currentIndex = 0;
  final List<Widget> _pages = [
    ExplorePage(),
    RoadmapPage(),
    ProfilePage(),
    PlayToLearnPage(),
    EntrepreneurshipPage(),
    NetworkingPage(),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('C.V Light'),
      ),
      body: _pages[_currentIndex],
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _currentIndex,
        type: BottomNavigationBarType.fixed,
        onTap: (index) {
          setState(() {
            _currentIndex = index;
          });
        },
        items: [
          BottomNavigationBarItem(icon: Icon(Icons.trending_up), label: 'Explore'),
          BottomNavigationBarItem(icon: Icon(Icons.map), label: 'Roadmap'),
          BottomNavigationBarItem(icon: Icon(Icons.person), label: 'Profile'),
          BottomNavigationBarItem(icon: Icon(Icons.videogame_asset), label: 'Play'),
          BottomNavigationBarItem(icon: Icon(Icons.lightbulb), label: 'Entrepreneur'),
          BottomNavigationBarItem(icon: Icon(Icons.work), label: 'Network'),
        ],
      ),
    );
  }
}

class ExplorePage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Center(child: Text('Explore Career Trends'));
  }
}

class RoadmapPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Center(child: Text('Career Roadmap'));
  }
}

class ProfilePage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Center(child: Text('Profile & Progress Dashboard'));
  }
}

class PlayToLearnPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Center(child: Text('Play to Learn (Soft Skills)'));
  }
}

class EntrepreneurshipPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Center(child: Text('Entrepreneurship Toolkit'));
  }
}

class NetworkingPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Center(child: Text('Networking & Job Applications'));
  }
}
